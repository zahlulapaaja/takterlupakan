<!--begin::Header-->
<div id="kt_header" class="header">
	<!--begin::Container-->
	<div class="container-fluid d-flex align-items-center flex-wrap justify-content-between" id="kt_header_container">
        <?php echo $__env->make(config('settings.KT_THEME_LAYOUT_DIR').'/partials/content-layout/header/_title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make(config('settings.KT_THEME_LAYOUT_DIR').'/partials/content-layout/header/_mobile-toggle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--begin::Topbar-->
		<div class="d-flex align-items-center flex-shrink-0">
            <?php echo $__env->make(config('settings.KT_THEME_LAYOUT_DIR').'/partials/content-layout/header/_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make(config('settings.KT_THEME_LAYOUT_DIR').'/partials/content-layout/header/_activities', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make(config('settings.KT_THEME_LAYOUT_DIR').'/partials/content-layout/header/_chat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make(config('settings.KT_THEME_LAYOUT_DIR').'/partials/content-layout/header/_theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!--begin::Sidebar Toggler-->
			<!--end::Sidebar Toggler-->
		</div>
		<!--end::Topbar-->
	</div>
	<!--end::Container-->
</div>
<!--end::Header--><?php /**PATH D:\takterlupakan\resources\views/layout/partials/content-layout/_header.blade.php ENDPATH**/ ?>