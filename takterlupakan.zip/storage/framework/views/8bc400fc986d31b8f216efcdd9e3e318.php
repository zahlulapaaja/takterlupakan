
<?php $__env->startPush('css'); ?>
<style type="text/css" media="print">
    @page {
        size: auto;
        margin: 0mm;
        padding: 12mm 16mm;

    }

    body {
        width: 21cm;
        height: 29.7cm;
        color: black !important;
    }

    .page-break {
        display: block;
        page-break-before: always;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="flex flex-col place-items-center text-center font-bold uppercase">
    <img class="w-24" src="<?php echo e(image('logos/logo-bps.png')); ?>">
    <div class="text-3xl italic mb-8"><?php echo e(config('constants.INSTANSI')); ?><br><?php echo e(config('constants.KABUPATEN')); ?></div>
    <?php echo $__env->yieldContent('head-print'); ?>
</div>
<div>
    <?php echo e($slot); ?>

</div>


<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    window.addEventListener("load", window.print());
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\takterlupakan\resources\views/layout/_print.blade.php ENDPATH**/ ?>