<!--begin::Modals-->
<?php echo $__env->make('components/modals/_invite-friend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
include('components/modals/_user-search')
<?php echo $__env->make('components/modals/_modal-add-no-fp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--end::Modals--><?php /**PATH D:\takterlupakan\resources\views/components/_modals.blade.php ENDPATH**/ ?>