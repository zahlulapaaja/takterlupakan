<!--begin::Drawers-->
<?php echo $__env->make('components/drawers/_activity-drawer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/drawers/_chat-drawer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/drawers/_shopping-cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--end::Drawers--><?php /**PATH D:\takterlupakan\resources\views/components/_drawers.blade.php ENDPATH**/ ?>