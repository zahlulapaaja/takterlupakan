<table class="w-full border text-center font-medium mb-4">
    <thead>
        <tr>
            <th class="border border-black py-1 font-bold">No.</th>
            <th class="border border-black py-1 font-bold">Uraian</th>
            <th class="border border-black py-1 font-bold">Honor (Rp)</th>
        </tr>
        <tr class="text-sm font-thin">
            <td class="border border-black">(1)</td>
            <td class="border border-black">(2)</td>
            <td class="border border-black">(3)</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data->honor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="border border-black"><?php echo e($key+1); ?>.</td>
            <td class="border border-black text-left min-w-300px pl-2"><?php echo e($h->uraian); ?></td>
            <td class="border border-black"><?php echo e($h->honor); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\takterlupakan\resources\views/kegiatan/_sk-tabel-honor.blade.php ENDPATH**/ ?>