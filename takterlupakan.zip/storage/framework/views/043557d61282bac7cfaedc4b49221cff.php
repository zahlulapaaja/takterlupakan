<!--begin::Chat-->
<div class="d-flex d-none align-items-center ms-3 ms-lg-4">
	<!--begin::Drawer wrapper-->
	<div class="btn btn-icon btn-color-gray-700 btn-active-color-primary btn-outline w-40px h-40px position-relative" id="kt_drawer_chat_toggle">
		<i class="ki-duotone ki-message-text-2 fs-1">
			<span class="path1"></span>
			<span class="path2"></span>
			<span class="path3"></span>
		</i>
		<!--begin::Bullet-->
		<span class="bullet bullet-dot bg-success h-6px w-6px position-absolute translate-middle top-0 start-50 animation-blink"></span>
		<!--end::Bullet-->
	</div>
	<!--end::Drawer wrapper-->
</div>
<!--end::Chat--><?php /**PATH D:\takterlupakan\resources\views/layout/partials/content-layout/header/_chat.blade.php ENDPATH**/ ?>