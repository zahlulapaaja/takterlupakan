<?php $j = $k = $l = $m = $n = $o = $p = 0; ?>
<?php $q = 1; ?>
<?php for($i = 0; $i < count($poks); $i++): ?>
    <?php
    if ($i > 0) {
        $sama['program'] = $poks[$i]->kode_program == $poks[$i - 1]->kode_program;
        $sama['kegiatan'] = $poks[$i]->kode_kegiatan == $poks[$i - 1]->kode_kegiatan;
        $sama['output'] = $poks[$i]->kode_output == $poks[$i - 1]->kode_output;
        $sama['suboutput'] = $poks[$i]->kode_suboutput == $poks[$i - 1]->kode_suboutput;
        $sama['komponen'] = $poks[$i]->kode_komponen == $poks[$i - 1]->kode_komponen;
        $sama['subkomponen'] = $poks[$i]->kode_subkoponen == $poks[$i - 1]->kode_subkoponen;
        $sama['akun'] = $poks[$i]->kode_akun == $poks[$i - 1]->kode_akun;
    } else {
        // jadi baris nol akan dianggap true semua nanti
        $sama['program'] = false;
        $sama['kegiatan'] = false;
        $sama['output'] = false;
        $sama['suboutput'] = false;
        $sama['komponen'] = false;
        $sama['subkomponen'] = false;
        $sama['akun'] = false;
    }
    ?>
    <!-- begin::Program -->
    <?php if( !$sama['program'] ): ?>
    <tr class="bg-red-300">
        <td>
            <span class="text-gray-900 fw-semibold text-center text-hover-black d-block fs-6"><?php echo e($q++); ?></span>
        </td>
        <td colspan="4">
            <span class="pl-0 text-gray-900 fw-bold text-hover-black mb-1 fs-6"><?php echo e($pokk['program'][$j]); ?></span>
        </td>
        <td>
            <span class="text-gray-900 fw-semibold text-right text-hover-black d-block fs-6"><?php echo e($jlh_pokk['program'][$j]); ?></span>
        </td>
    </tr>
    <?php $j++; ?>
    <?php endif; ?>
    <!-- begin::Kegiatan -->
    <?php if( !($sama['program'] && $sama['kegiatan']) ): ?>
    <tr class="bg-orange-300">
        <td>
            <span class="text-gray-900 fw-semibold text-center text-hover-black d-block fs-6"><?php echo e($q++); ?></span>
        </td>
        <td colspan="4">
            <span class="pl-2 text-gray-900 fw-bold text-hover-black mb-1 fs-6"><?php echo e($pokk['kegiatan'][$k]); ?></span>
        </td>
        <td>
            <span class="text-gray-900 fw-semibold text-right text-hover-black d-block fs-6"><?php echo e($jlh_pokk['kegiatan'][$k]); ?></span>
        </td>
    </tr>
    <?php $k++; ?>
    <?php endif; ?>
    <!-- begin::Output -->
    <?php if( !($sama['program'] && $sama['kegiatan'] && $sama['output']) ): ?>
    <tr class="bg-amber-300">
        <td>
            <span class="text-gray-900 fw-semibold text-center text-hover-black d-block fs-6"><?php echo e($q++); ?></span>
        </td>
        <td colspan="4">
            <span class="pl-4 text-gray-900 fw-bold text-hover-black mb-1 fs-6"><?php echo e($pokk['output'][$l]); ?></span>
        </td>
        <td>
            <span class="text-gray-900 fw-semibold text-right text-hover-black d-block fs-6"><?php echo e($jlh_pokk['output'][$l]); ?></span>
        </td>
    </tr>
    <?php $l++; ?>
    <?php endif; ?>
    <!-- begin::Sub Output -->
    <?php if( !($sama['program'] && $sama['kegiatan'] && $sama['output'] && $sama['suboutput']) ): ?>
    <tr class="bg-yellow-300">
        <td>
            <span class="text-gray-900 fw-semibold text-center text-hover-black d-block fs-6"><?php echo e($q++); ?></span>
        </td>
        <td colspan="4">
            <span class="pl-6 text-gray-900 fw-bold text-hover-black mb-1 fs-6"><?php echo e($pokk['suboutput'][$m]); ?></span>
        </td>
        <td>
            <span class="text-gray-900 fw-semibold text-right text-hover-black d-block fs-6"><?php echo e($jlh_pokk['suboutput'][$m]); ?></span>
        </td>
    </tr>
    <?php $m++; ?>
    <?php endif; ?>
    <!-- begin::Komponen -->
    <?php if( !($sama['program'] && $sama['kegiatan'] && $sama['output'] && $sama['suboutput'] && $sama['komponen']) ): ?>
    <tr class="bg-lime-300">
        <td>
            <span class="text-gray-900 fw-semibold text-center text-hover-black d-block fs-6"><?php echo e($q++); ?></span>
        </td>
        <td colspan="4">
            <span class="pl-8 text-gray-900 fw-bold text-hover-black mb-1 fs-6"><?php echo e($pokk['komponen'][$n]); ?></span>
        </td>
        <td class="p-0">
            <span class="text-gray-900 fw-semibold text-right text-hover-black d-block fs-6"><?php echo e($jlh_pokk['komponen'][$n]); ?></span>
        </td>
        <td class="bg-white">
            <form method="post" action="<?php echo e(route('kegiatan.sk.create')); ?>" class="text-gray-900 fw-semibold text-center text-hover-black d-block">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <input type="hidden" name="kode_kegiatan" value="<?php echo e($poks[$i]->kode_kegiatan); ?>" />
                <input type="hidden" name="kode_output" value="<?php echo e($poks[$i]->kode_output); ?>" />
                <input type="hidden" name="output" value="<?php echo e($poks[$i]->output); ?>" />
                <input type="hidden" name="kode_suboutput" value="<?php echo e($poks[$i]->kode_suboutput); ?>" />
                <input type="hidden" name="suboutput" value="<?php echo e($poks[$i]->suboutput); ?>" />
                <input type="hidden" name="kode_komponen" value="<?php echo e($poks[$i]->kode_komponen); ?>" />
                <input type="hidden" name="komponen" value="<?php echo e($poks[$i]->komponen); ?>" />
                <button type="submit"> SK </button>
            </form>
        </td>
    </tr>
    <?php $n++; ?>
    <?php endif; ?>
    <!-- begin::Sub Komponen -->
    <?php if( !($sama['program'] && $sama['kegiatan'] && $sama['output'] && $sama['suboutput'] && $sama['komponen'] && $sama['subkomponen']) ): ?>
    <tr class="bg-lime-300">
        <td>
            <span class="text-gray-900 fw-semibold text-center text-hover-black d-block fs-6"><?php echo e($q++); ?></span>
        </td>
        <td colspan="4">
            <span class="pl-8 text-gray-900 fw-bold text-hover-black mb-1 fs-6"><?php echo e($pokk['subkomponen'][$o]); ?></span>
        </td>
        <td>
            <span class="text-gray-900 fw-semibold text-right text-hover-black d-block fs-6"><?php echo e($jlh_pokk['subkomponen'][$o]); ?></span>
        </td>
    </tr>
    <?php $o++; ?>
    <?php endif; ?>
    <!-- begin::Akun -->
    <?php if( !($sama['program'] && $sama['kegiatan'] && $sama['output'] && $sama['suboutput'] && $sama['komponen'] && $sama['subkomponen'] && $sama['akun']) ): ?>
    <tr class="bg-cyan-300">
        <td>
            <span class="text-gray-900 fw-semibold text-center text-hover-black d-block fs-6"><?php echo e($q++); ?></span>
        </td>
        <td colspan="4">
            <span class="pl-10 text-gray-900 fw-bold text-hover-black mb-1 fs-6"><?php echo e($pokk['akun'][$p]); ?></span>
        </td>
        <td>
            <span class="text-gray-900 fw-semibold text-right text-hover-black d-block fs-6"><?php echo e($jlh_pokk['akun'][$p]); ?></span>
        </td>
        <?php if(in_array($poks[$i]->kode_akun, $list_akun_input)): ?>
        <!-- <td class="bg-white">
            <form method="post" action="<?php echo e(route('kegiatan.pjk.create')); ?>" class="text-gray-900 fw-semibold text-center text-hover-black d-block">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <select name="pj">
                    <option value="">1</option>
                    <option value="">2</option>
                    <option value="">4</option>
                </select>
                <input type="hidden" name="kode_kegiatan" value="<?php echo e($poks[$i]->kode_kegiatan); ?>" />
                <input type="hidden" name="kode_output" value="<?php echo e($poks[$i]->kode_output); ?>" />
                <input type="hidden" name="output" value="<?php echo e($poks[$i]->output); ?>" />
                <input type="hidden" name="kode_suboutput" value="<?php echo e($poks[$i]->kode_suboutput); ?>" />
                <input type="hidden" name="suboutput" value="<?php echo e($poks[$i]->suboutput); ?>" />
                <input type="hidden" name="kode_komponen" value="<?php echo e($poks[$i]->kode_komponen); ?>" />
                <input type="hidden" name="komponen" value="<?php echo e($poks[$i]->komponen); ?>" />
                <button type="submit"> PJ </button>
            </form>
        </td> -->
        <?php endif; ?>
    </tr>
    <?php $p++; ?>
    <?php endif; ?>
    <!-- begin::Item Kegiatan -->
    <tr class="hover:bg-blue-600">
        <td>
            <span class="text-gray-900 fw-semibold text-center text-hover-black d-block fs-6"><?php echo e($q++); ?></span>
        </td>
        <td>
            <span class="pl-16 text-gray-900 fw-bold text-hover-black mb-1 fs-6"><?php echo e(' - ' . $poks[$i]->item_kegiatan); ?></span>
        </td>
        <td>
            <span class="text-gray-900 fw-semibold text-center text-hover-black d-block fs-6"><?php echo e($poks[$i]->volume); ?></span>
        </td>
        <td>
            <span class="text-gray-900 fw-semibold text-center text-hover-black d-block fs-6"><?php echo e($poks[$i]->satuan); ?></span>
        </td>
        <td>
            <span class="text-gray-900 fw-semibold text-right text-hover-black d-block fs-6"><?php echo e($poks[$i]->harga); ?></span>
        </td>
        <td>
            <span class="text-gray-900 fw-semibold text-right text-hover-black d-block fs-6"><?php echo e($poks[$i]->jumlah); ?></span>
        </td>
        <?php if(in_array($poks[$i]->kode_akun, $list_akun_input)): ?>
        <!-- <td class="bg-white">
            <form method="post" action="<?php echo e(route('kegiatan.item.create')); ?>" class="text-gray-900 fw-semibold text-center text-hover-black d-block">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <input type="hidden" name="pok_id" value="<?php echo e($poks[$i]->id); ?>" />
                <button type="submit"> Input </button>
            </form>
        </td> -->
        <?php endif; ?>
    </tr>
    <!-- end::Item Kegiatan -->
    <!-- end::Akun -->
    <!-- end::Sub Komponen -->
    <!-- end::Komponen -->
    <!-- end::Sub Output -->
    <!-- end::Output -->
    <!-- end::Kegiatan -->
    <!-- end::Program -->
    <?php endfor; ?><?php /**PATH D:\takterlupakan\resources\views/pok/_table-body-pok.blade.php ENDPATH**/ ?>