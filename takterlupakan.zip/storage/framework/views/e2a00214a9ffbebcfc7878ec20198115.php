<!--begin::Activities-->
<div class="d-flex align-items-center ms-3 ms-lg-4">
	<!--begin::Drawer toggle-->
	<div class="btn btn-icon btn-color-gray-700 btn-active-color-primary btn-outline w-40px h-40px" id="kt_activities_toggle">
		<i class="ki-duotone ki-notification-bing fs-1">
			<span class="path1"></span>
			<span class="path2"></span>
			<span class="path3"></span>
		</i>
	</div>
	<!--end::Drawer toggle-->
</div>
<!--end::Activities--><?php /**PATH D:\takterlupakan\resources\views/layout/partials/content-layout/header/_activities.blade.php ENDPATH**/ ?>