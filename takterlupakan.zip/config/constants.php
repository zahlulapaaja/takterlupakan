<?php

return [

    'INSTANSI' => 'Badan Pusat Statistik',
    'KABUPATEN' => 'Kabupaten Aceh Barat',
    'SATKER' => 'BPS Kabupaten Aceh Barat',
    'MEULABOH' => 'Meulaboh',




    // dibawah ini seharusnya di database dan bisa berubah

    // pok
    'DIPA' => 'SP DIPA-054.01.2.019738/2024',
    'TANGGAL_DIPA' => '24 November 2023',
    'TAHUN_DIPA' => '2024',

    // pejabat
    'KPA' => 'Rudi Hermanto, S.ST, M.Si',
    'NIP_KPA' => '197804192002121002',

    // keputusan kepala
    'NO_SK_KPA' => '51/PA/2023',
    'TANGGAL_SK_KPA' => '6 Maret 2023',


];
