<!--begin::Drawers-->
@include('components/drawers/_activity-drawer')
@include('components/drawers/_chat-drawer')
@include('components/drawers/_shopping-cart')
<!--end::Drawers-->