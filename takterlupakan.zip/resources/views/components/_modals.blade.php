<!--begin::Modals-->
@include('components/modals/_invite-friend')
include('components/modals/_user-search')
@include('components/modals/_modal-add-no-fp')

<!--end::Modals-->